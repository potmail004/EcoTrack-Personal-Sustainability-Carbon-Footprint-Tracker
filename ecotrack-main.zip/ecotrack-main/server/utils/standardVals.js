export const standardWaterValues = {
	drinking: 5,
	cooking: 5,
	bathing: 55,
	clothWashing: 20,
	utensilsWashing: 10,
	houseWashing: 10,
	waterClosetsFlushing: 30,
	others: 5,
};

export const standardCarbonValues = {
	transport: 130,
	electricity: 130,
	others: 130,
};
